SELECT
    v.date_vente,
    p.nom_produit,
    vi.nom_ville,
    v.quantite_vendue
FROM ventes AS v
INNER JOIN produits AS p
    ON v.id_produit = p.id_produit
INNER JOIN magasins AS m
    ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vi
    ON m.id_ville = vi.id_ville;




SELECT
    p.nom_produit,
    p.prix,
    v.quantite_vendue,
    vi.nom_ville
FROM ventes AS v
INNER JOIN produits AS p
    ON v.id_produit = p.id_produit
INNER JOIN magasins AS m
    ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vi
    ON m.id_ville = vi.id_ville
WHERE vi.nom_ville IN ('Goma', 'Bukavu');




-- top katanga

SELECT
    p.nom_produit,
    SUM(v.quantite_vendue) AS total_quantites
FROM ventes AS v
INNER JOIN produits AS p
    ON v.id_produit = p.id_produit
INNER JOIN categories AS c
    ON p.id_categorie = c.id_categorie
INNER JOIN magasins AS m
    ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vi
    ON m.id_ville = vi.id_ville
WHERE vi.nom_ville = 'Lubumbashi'
AND c.nom_categorie = 'Running'
GROUP BY p.nom_produit;



-- La rentabilité par Magasin

SELECT
    m.nom_magasin,
    vi.nom_ville,
    SUM(v.quantite_vendue * p.prix) AS chiffre_affaires_total
FROM ventes AS v
INNER JOIN produits AS p
    ON v.id_produit = p.id_produit
INNER JOIN magasins AS m
    ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vi
    ON m.id_ville = vi.id_ville
GROUP BY m.nom_magasin, vi.nom_ville
ORDER BY chiffre_affaires_total DESC;



--L'inventaire des catégories par Ville

SELECT DISTINCT
    vi.nom_ville,
    c.nom_categorie
FROM ventes AS v
INNER JOIN produits AS p
    ON v.id_produit = p.id_produit
INNER JOIN categories AS c
    ON p.id_categorie = c.id_categorie
INNER JOIN magasins AS m
    ON v.id_magasin = m.id_magasin
INNER JOIN villes AS vi
    ON m.id_ville = vi.id_ville
ORDER BY vi.nom_ville, c.nom_categorie;